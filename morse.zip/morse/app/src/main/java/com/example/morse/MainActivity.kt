package com.example.morse

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import kotlin.concurrent.thread

// =====================================================================
// MÓDULO DE SEGURIDAD (ISO/IEC 27400 y Lineamientos OT)
// =====================================================================
object IoTSecurityManager {
    fun getEncryptedPrefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        "secure_iot_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun sanitizeInput(input: String): String {
        return input.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' || it == ' ' }
    }

    fun hashPassword(pass: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pass.toByteArray(StandardCharsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

// =====================================================================
// MÓDULO DE CONECTIVIDAD BLUETOOTH (RFCOMM)
// =====================================================================
class BluetoothIoTManager(private val onDataReceived: (String) -> Unit) {
    private var socket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null
    private var isListening = false
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice, onResult: (Boolean) -> Unit) {
        thread {
            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket?.connect()
                outputStream = socket?.outputStream
                inputStream = socket?.inputStream
                isListening = true
                startListening()
                onResult(true)
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false)
            }
        }
    }

    fun sendSecureData(text: String) {
        thread {
            try {
                val sanitized = IoTSecurityManager.sanitizeInput(text)
                val payload = sanitized + "\n"
                outputStream?.write(payload.toByteArray(StandardCharsets.UTF_8))
                outputStream?.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun startListening() {
        thread {
            val buffer = ByteArray(1024)
            while (isListening) {
                try {
                    val bytesRead = inputStream?.read(buffer) ?: -1
                    if (bytesRead > 0) {
                        val rawData = String(buffer, 0, bytesRead).trim()
                        onDataReceived(rawData)
                    }
                } catch (e: Exception) {
                    isListening = false
                    break
                }
            }
        }
    }

    fun disconnect() {
        isListening = false
        try {
            socket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

// =====================================================================
// ACTIVIDAD PRINCIPAL Y NAVEGACION
// =====================================================================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRootNavigator(context = this)
                }
            }
        }
    }
}

@Composable
fun AppRootNavigator(context: Context) {
    var isAuthenticated by remember { mutableStateOf(false) }

    if (!isAuthenticated) {
        LoginScreen(context = context) { isAuthenticated = true }
    } else {
        MonitoringAndActivatorScreen()
    }
}

// =====================================================================
// PANTALLA DE LOGIN
// =====================================================================
@Composable
fun LoginScreen(context: Context, onLoginSuccess: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val prefs = remember { IoTSecurityManager.getEncryptedPrefs(context) }
// =====================================================================
// USUARIO: admin // CONTRASEÑA: admin123
// =====================================================================
    val defaultUser = "admin"
    val defaultPassHash = IoTSecurityManager.hashPassword("admin123")

    if (prefs.getString("STORED_USER", null) == null) {
        prefs.edit()
            .putString("STORED_USER", defaultUser)
            .putString("STORED_PASS", defaultPassHash)
            .apply()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Acceso a Sistema IoT OT", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text("ISO/IEC 27400 - Autenticación Segura", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Usuario") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val savedUser = prefs.getString("STORED_USER", "")
                val savedPassHash = prefs.getString("STORED_PASS", "")
                val inputPassHash = IoTSecurityManager.hashPassword(password)

                if (username.trim() == savedUser && inputPassHash == savedPassHash) {
                    onLoginSuccess()
                } else {
                    errorMessage = "Credenciales incorrectas. Intente nuevamente."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Iniciar Sesión")
        }
    }
}

// =====================================================================
// PANTALLA DE MONITOREO Y ACTIVADOR
// =====================================================================
@Composable
fun MonitoringAndActivatorScreen() {
    var messageInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(false) }
    val transmissionLogs = remember { mutableStateListOf<String>() }

    val bluetoothManager = remember {
        BluetoothIoTManager { incomingData ->
            transmissionLogs.add(0, "[RX Recibido]: $incomingData")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            bluetoothManager.disconnect()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isConnected) Color(0xFFD4EDDA) else Color(0xFFF8D7DA)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isConnected) "Estado: Conectado a Dispositivo IoT" else "Estado: Desconectado",
                    color = if (isConnected) Color(0xFF155724) else Color(0xFF721C24),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        isConnected = true
                        transmissionLogs.add(0, "[Sistema]: Conexión RFCOMM establecida con éxito.")
                    },
                    enabled = !isConnected,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isConnected) "Conectado" else "Vincular Dispositivo Bluetooth")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Panel de Activación (Traductor / Comandos)", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            label = { Text("Texto a convertir/enviar") },
            placeholder = { Text("Ejemplo: SOS") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (messageInput.isNotBlank()) {
                    val sanitized = IoTSecurityManager.sanitizeInput(messageInput)
                    bluetoothManager.sendSecureData(sanitized)
                    transmissionLogs.add(0, "[TX Enviado]: $sanitized")
                    messageInput = ""
                }
            },
            enabled = isConnected,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Enviar Tramas al Dispositivo IoT")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Consola de Monitoreo Inalámbrico:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF121212))
                .padding(8.dp)
        ) {
            items(transmissionLogs) { log ->
                Text(
                    text = log,
                    color = Color(0xFF00FF66),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
            }
        }
    }
}